console.log("Hi, Javascript!");
console.log("Thank you.");

